# Enigma

A simple emulator of the M3 enigma machine used by the germans during WWII. This project was created for educational
purpose and is not actively maintained.

## Instalation

clone the repo and install (in virtual environment):

```shell
git clone git@github.com:danjer/enigma.git
cd enigma
pip install -e .
```

## Usage
You can start the GUI by executing
```shell
engima-emulator
```
